
<div class="modal fade" id="modal-pass">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Modal title</h4>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" role="form" id="form-change">
				  <div class="form-group">
				    <label class="control-label col-sm-2" for="pwd">Password:</label>
				    <div class="col-sm-10">
				      <input type="password" class="form-control" id="pwd" placeholder="Enter Password" required="">
				    </div>
				  </div>
				  <div class="form-group">
				    <label class="control-label col-sm-2" for="pwd2">Confirm:</label>
				    <div class="col-sm-10"> 
				      <input type="password" class="form-control" id="pwd2" placeholder="Confirm password" required="">
				    </div>
				  </div>
				  
				  <div class="form-group"> 
				    <div class="col-sm-offset-2 col-sm-10">
				      <button type="submit" class="btn btn-success">Save Changes</button>
				    </div>
				  </div>
				</form>				
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>